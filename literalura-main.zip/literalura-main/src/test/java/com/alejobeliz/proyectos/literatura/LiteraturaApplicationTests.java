package com.alejobeliz.proyectos.literatura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiteraturaApplicationTests {

	@Test
	void contextLoads() {
	}

}
